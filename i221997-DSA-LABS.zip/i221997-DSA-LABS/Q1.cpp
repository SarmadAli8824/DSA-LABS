#include<iostream>
using namespace std;
int main()
{
	int day, month, year;
	cout << "Enter day : " << endl;
	cin >> day;
	cout << "Enter month : " << endl;
	cin >> month;
	cout << "Enter year : " << endl;
	cin >> year;
	cout << endl;
	cout << "The day,month, and year entered are : " << day << "/" << month << "/" << year << endl;

}