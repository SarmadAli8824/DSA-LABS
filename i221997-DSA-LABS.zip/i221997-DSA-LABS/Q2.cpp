#include <iostream>
#include <cmath>
using namespace std;
class Point 
{
private:
    double w,x, y,z;
public:
    Point() {}
    //Getter for x 
    double getX() const 
    {
        return x;
    }

    //Setter for x 
    void setX(double newX) 
    {
        x = newX;
    }

    //Getter for y 
    double getY() const 
    {
        return y;
    }

    //Setter for y 
    void setY(double newY) 
    {
        y = newY;
    }
    //Getter for w
    double getW() const
    {
        return w;
    }

    //Setter for w
    void setW(double newW)
    {
        w = newW;
    }

    //Getter for z
    double getZ() const
    {
        return z;
    }

    //Setter for z 
    void setZ(double newZ)
    {
        z = newZ;
    }

    //Function to calculate distance 
    double distance() const 
    {
        return sqrt(pow(w-y,2)+pow(x-z,2));
    }
};
int main() 
{
    Point p1;
    p1.setW(2);
    p1.setX(3);
    p1.setY(5);
    p1.setZ(6);
    //Coordinates of p1 are displayed
    cout<<"Coordinates of p1: " << p1.getW() << ", " << p1.getX() << endl; 
    //Coordinates of p2 are displayed
    cout<<"Coordinates of p2: "<<p1.getY() << ", " << p1.getZ() << endl;
    //Distance between p1 and p2
    cout << "Distance between p1 and p2: " << p1.distance() << endl;
    return 0;
}